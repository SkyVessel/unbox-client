package fuzs.easyshulkerboxes.fabric.client;

import fuzs.easyshulkerboxes.common.EasyShulkerBoxes;
import fuzs.easyshulkerboxes.common.client.EasyShulkerBoxesClient;
import fuzs.puzzleslib.common.api.client.core.v1.ClientModConstructor;
import net.fabricmc.api.ClientModInitializer;

public class EasyShulkerBoxesFabricClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ClientModConstructor.construct(EasyShulkerBoxes.MOD_ID, EasyShulkerBoxesClient::new);
    }
}
