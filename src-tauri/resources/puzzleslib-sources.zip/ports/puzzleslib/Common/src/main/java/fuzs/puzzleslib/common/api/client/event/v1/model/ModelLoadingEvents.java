package fuzs.puzzleslib.common.api.client.event.v1.model;

import fuzs.puzzleslib.common.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.common.api.event.v1.core.EventResultHolder;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.resources.model.UnbakedModel;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.state.BlockState;

@Deprecated
public final class ModelLoadingEvents {
    public static final EventInvoker<LoadModel> LOAD_MODEL = EventInvoker.lookup(LoadModel.class);
    public static final EventInvoker<LoadBlockModel> LOAD_BLOCK_MODEL = EventInvoker.lookup(LoadBlockModel.class);

    private ModelLoadingEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface LoadModel {

        /**
         * An event that runs for every unbaked model. Allows for replacing the model.
         *
         * @param identifier   the identifier for the model
         * @param unbakedModel the unbaked model
         * @return <ul>
         *         <li>{@link EventResultHolder#interrupt(Object)} to replace the model</li>
         *         <li>{@link EventResultHolder#pass()} to allow the original model to be used</li>
         *         </ul>
         */
        EventResultHolder<UnbakedModel> onLoadModel(Identifier identifier, UnbakedModel unbakedModel);
    }

    @FunctionalInterface
    public interface LoadBlockModel {

        /**
         * An event that runs for every unbaked block model. Allows for replacing the model.
         *
         * @param blockState   the block state the model is loaded for
         * @param unbakedModel the unbaked block model
         * @return <ul>
         *         <li>{@link EventResultHolder#interrupt(Object)} to replace the model</li>
         *         <li>{@link EventResultHolder#pass()} to allow the original model to be used</li>
         *         </ul>
         */
        EventResultHolder<BlockStateModel.UnbakedRoot> onLoadBlockModel(BlockState blockState, BlockStateModel.UnbakedRoot unbakedModel);
    }
}
