package fuzs.puzzleslib.common.api.client.event.v1.model;

import fuzs.puzzleslib.common.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.common.api.event.v1.core.EventResultHolder;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.item.ItemModel;
import net.minecraft.client.resources.model.ModelBaker;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.state.BlockState;

@Deprecated
public final class ModelBakingEvents {
    public static final EventInvoker<BeforeBlock> BEFORE_BLOCK = EventInvoker.lookup(BeforeBlock.class);
    public static final EventInvoker<AfterBlock> AFTER_BLOCK = EventInvoker.lookup(AfterBlock.class);
    public static final EventInvoker<BeforeItem> BEFORE_ITEM = EventInvoker.lookup(BeforeItem.class);
    public static final EventInvoker<AfterItem> AFTER_ITEM = EventInvoker.lookup(AfterItem.class);

    private ModelBakingEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface BeforeBlock {

        /**
         * An event that runs for every unbaked block model. Allows for replacing the model.
         *
         * @param blockState   the block state the model is loaded for
         * @param unbakedModel the unbaked block model
         * @param modelBaker   the model baker instance
         * @return <ul>
         *         <li>{@link EventResultHolder#interrupt(Object)} to replace the model</li>
         *         <li>{@link EventResultHolder#pass()} to allow the original model to be used</li>
         *         </ul>
         */
        EventResultHolder<BlockStateModel.UnbakedRoot> onBeforeBakeBlock(BlockState blockState, BlockStateModel.UnbakedRoot unbakedModel, ModelBaker modelBaker);
    }

    @FunctionalInterface
    public interface AfterBlock {

        /**
         * An event that runs for every baked block model. Allows for replacing the model.
         *
         * @param blockState   the block state the model is loaded for
         * @param bakedModel   the baked block model
         * @param unbakedModel the original unbaked block model
         * @param modelBaker   the model baker instance
         * @return <ul>
         *         <li>{@link EventResultHolder#interrupt(Object)} to replace the model</li>
         *         <li>{@link EventResultHolder#pass()} to allow the original model to be used</li>
         *         </ul>
         */
        EventResultHolder<BlockStateModel> onAfterBakeBlock(BlockState blockState, BlockStateModel bakedModel, BlockStateModel.UnbakedRoot unbakedModel, ModelBaker modelBaker);
    }

    @FunctionalInterface
    public interface BeforeItem {

        /**
         * An event that runs for every unbaked item model. Allows for replacing the model.
         *
         * @param identifier   the identifier for the item
         * @param unbakedModel the unbaked item model
         * @param context      the item baking context instance
         * @return <ul>
         *         <li>{@link EventResultHolder#interrupt(Object)} to replace the model</li>
         *         <li>{@link EventResultHolder#pass()} to allow the original model to be used</li>
         *         </ul>
         */
        EventResultHolder<ItemModel.Unbaked> onBeforeBakeItem(Identifier identifier, ItemModel.Unbaked unbakedModel, ItemModel.BakingContext context);
    }

    @FunctionalInterface
    public interface AfterItem {

        /**
         * An event that runs for every baked item model. Allows for replacing the model.
         *
         * @param identifier   the identifier for the item
         * @param bakedModel   the baked item model
         * @param unbakedModel the original unbaked item model
         * @param context      the item baking context instance
         * @return <ul>
         *         <li>{@link EventResultHolder#interrupt(Object)} to replace the model</li>
         *         <li>{@link EventResultHolder#pass()} to allow the original model to be used</li>
         *         </ul>
         */
        EventResultHolder<ItemModel> onAfterBakeItem(Identifier identifier, ItemModel bakedModel, ItemModel.Unbaked unbakedModel, ItemModel.BakingContext context);
    }
}
