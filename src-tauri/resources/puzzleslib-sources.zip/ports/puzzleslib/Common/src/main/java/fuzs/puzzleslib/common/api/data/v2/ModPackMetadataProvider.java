package fuzs.puzzleslib.common.api.data.v2;

import fuzs.puzzleslib.common.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.common.api.resources.v1.PackResourcesHelper;
import net.minecraft.DetectedVersion;
import net.minecraft.data.PackOutput;
import net.minecraft.data.metadata.PackMetadataGenerator;
import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.metadata.pack.PackFormat;
import net.minecraft.server.packs.metadata.pack.PackMetadataSection;

public final class ModPackMetadataProvider extends PackMetadataGenerator {

    public ModPackMetadataProvider(DataProviderContext context) {
        this(PackType.SERVER_DATA, context);
    }

    public ModPackMetadataProvider(PackType packType, DataProviderContext context) {
        this(packType, context.getModId(), context.getPackOutput());
    }

    public ModPackMetadataProvider(String modId, PackOutput packOutput) {
        this(PackType.SERVER_DATA, modId, packOutput);
    }

    public ModPackMetadataProvider(PackType packType, String modId, PackOutput packOutput) {
        super(packOutput);
        Component component = PackResourcesHelper.getPackDescription(modId);
        // Set only the major version here to stay compatible across different minor Minecraft versions.
        this.add(PackMetadataSection.forPackType(packType),
                new PackMetadataSection(component,
                        PackFormat.of(DetectedVersion.BUILT_IN.packVersion(packType).major()).minorRange()));
    }
}
