plugins {
    `kotlin-dsl`
    kotlin("plugin.serialization") version "2.3.0"
}

repositories {
    mavenCentral()
    gradlePluginPortal()
    maven("https://maven.fabricmc.net/")
    maven("https://papermc.io/repo/repository/maven-public/")
    maven("https://maven.quiltmc.org/repository/release/")
    maven("https://maven.neoforged.net/releases/")
}

dependencies {
    fun pluginDep(id: String, version: String) = "${id}:${id}.gradle.plugin:${version}"
    val kotlinVersion = "2.3.0"

    compileOnly(kotlin("gradle-plugin", kotlinVersion))
    runtimeOnly(kotlin("gradle-plugin", kotlinVersion))
    compileOnly(pluginDep("org.jetbrains.kotlin.plugin.serialization", kotlinVersion))
    runtimeOnly(pluginDep("org.jetbrains.kotlin.plugin.serialization", kotlinVersion))
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.10.+")

    // Fabric implementation
    implementation("net.fabricmc:fabric-loom:1.15-SNAPSHOT")

    // Paper implementation
    implementation(pluginDep("io.papermc.paperweight.userdev", "2.0.0-beta.21"))
    implementation(pluginDep("xyz.jpenilla.run-paper", "3.0.2"))
    implementation(pluginDep("de.eldoria.plugin-yml.paper", "0.7.+"))

    // NeoForge implementation
    implementation(pluginDep("net.neoforged.moddev", "2.0.141"))

    // Project configuration
    implementation(pluginDep("com.gradleup.shadow", "9.0.0"))
    implementation(pluginDep("com.modrinth.minotaur", "2.+"))
    implementation(pluginDep("net.darkhax.curseforgegradle", "1.3.32"))
    implementation(pluginDep("io.github.dexman545.outlet", "1.8.+"))
}
