package de.miraculixx.veinminer.command

import com.mojang.brigadier.tree.LiteralCommandNode
import de.miraculixx.veinminer.INSTANCE
import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEvents
import net.minecraft.commands.CommandBuildContext
import net.minecraft.server.MinecraftServer
import net.minecraft.world.flag.FeatureFlags
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player
import io.papermc.paper.command.brigadier.CommandSourceStack as PaperCommandSourceStack
import net.minecraft.commands.CommandSourceStack as NmsCommandSourceStack

object PaperVeinminerCommand {
    fun register() {
        Permissions.install { src, node ->
            val sender: CommandSender? = when (src) {
                is NmsCommandSourceStack -> runCatching { src.bukkitSender }.getOrNull()
                is PaperCommandSourceStack -> src.sender
                else -> null
            }
            // OP and console always pass; otherwise check Bukkit perm node
            sender?.isOp == true || sender?.hasPermission(node) == true || (sender !is Player)
        }

        INSTANCE.lifecycleManager.registerEventHandler(LifecycleEvents.COMMANDS) { event ->
            val server = MinecraftServer.getServer()
            val ctx = CommandBuildContext.simple(server.registryAccess(), FeatureFlags.REGISTRY.allFlags())
            val node = VeinminerCommand.build(ctx).build()
            @Suppress("UNCHECKED_CAST")
            event.registrar().register(
                node as LiteralCommandNode<PaperCommandSourceStack>,
                "Veinminer command",
            )
        }
    }
}
