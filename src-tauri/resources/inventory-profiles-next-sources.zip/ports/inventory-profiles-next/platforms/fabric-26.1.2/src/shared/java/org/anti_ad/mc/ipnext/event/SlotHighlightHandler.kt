/*
 * Inventory Profiles Next
 *
 *   Copyright (c) 2022 Plamen K. Kosseff <p.kosseff@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package org.anti_ad.mc.ipnext.event

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen
import org.anti_ad.mc.common.gui.NativeContext
import org.anti_ad.mc.common.math2d.Point
import org.anti_ad.mc.common.math2d.Rectangle
import org.anti_ad.mc.common.vanilla.Vanilla
import org.anti_ad.mc.common.vanilla.render.alpha
import org.anti_ad.mc.common.vanilla.render.glue.rFillRect
import org.anti_ad.mc.ipnext.config.Features
import org.anti_ad.mc.ipnext.config.ModSettings
import org.anti_ad.mc.ipnext.gui.base.InventoryOverlay
import org.anti_ad.mc.ipnext.ingame.`(containerBounds)`
import org.anti_ad.mc.ipnext.ingame.`(focusedSlot)`
import org.anti_ad.mc.ipnext.ingame.`(id)`
import org.anti_ad.mc.ipnext.ingame.`(itemStack)`
import org.anti_ad.mc.ipnext.ingame.`(slots)`
import org.anti_ad.mc.ipnext.ingame.`(topLeft)`
import org.anti_ad.mc.ipnext.ingame.vPlayerSlotOf
import org.anti_ad.mc.ipnext.item.EMPTY
import org.anti_ad.mc.ipnext.item.ItemType
import org.anti_ad.mc.ipnext.item.isEmpty


object SlotHighlightHandler: InventoryOverlay {

    private var toHighlight: ItemType? = null

    private var ticksSinceLastFocusChange = 3

    override val slotLocations: Map<Int, Point> // id, location // ref: LockSlotsHandler
        get() {
            val screen = Vanilla.screen() as? AbstractContainerScreen<*> ?: return mapOf()
            return Vanilla.container().`(slots)`.mapNotNull { slot ->
                val playerSlot = vPlayerSlotOf(slot,
                                               screen)
                return@mapNotNull if (!playerSlot.`(itemStack)`.isEmpty() && playerSlot.`(itemStack)`.itemType.copy(ignoreDurability = true) == toHighlight) {
                    playerSlot.`(id)` to slot.`(topLeft)`
                } else {
                    null
                }
            }.toMap()
        }

    override val enabledBackground: Boolean
        get() = Features.HIGHLIGHT_FOUSED_ITEMS.value && !ModSettings.HIGHLIGHT_FOCUSED_ITEMS_FOREGROUND.value

    override fun drawBackground(context: NativeContext) {
        drawSprite(context)
    }

    override val enabledForeground: Boolean
        get() = Features.HIGHLIGHT_FOUSED_ITEMS.value && ModSettings.HIGHLIGHT_FOCUSED_ITEMS_FOREGROUND.value

    override fun drawForeground(context: NativeContext) {
        drawSprite(context)
    }

    override fun drawConfig(context: NativeContext) {
    }

    override fun postRender(context: NativeContext) {

    }

    val defaultAlpha: Int
        get() {
            return if (ModSettings.HIGHLIGHT_FOCUSED_ITEMS_FOREGROUND.value) {
                ModSettings.HIGHLIGHT_FOCUSED_ITEMS_COLOR.value.alpha
            } else {
                ModSettings.HIGHLIGHT_FOCUSED_ITEMS_BG_COLOR.value.alpha
            }
        }
    val color: Int
        get() {
            return if (ModSettings.HIGHLIGHT_FOCUSED_ITEMS_FOREGROUND.booleanValue) {
                ModSettings.HIGHLIGHT_FOCUSED_ITEMS_COLOR.value
            } else {
                ModSettings.HIGHLIGHT_FOCUSED_ITEMS_BG_COLOR.value
            }
        }

    var tick = 0
    var alphaChannel = 10
    var step = 10

    private fun drawSprite(context: NativeContext) {
        //if (!enabled) return
        val screen = Vanilla.screen() as? AbstractContainerScreen<*> ?: return
        //    rClearDepth() // use translate or zOffset
        val localSlotLocations: MutableMap<Int, Point> = mutableMapOf()
        localSlotLocations.putAll(slotLocations)
        if (localSlotLocations.isNotEmpty()) {
            if (ModSettings.HIGHLIGHT_FOCUSED_ITEMS_ANIMATED.booleanValue) {
                tick++
                if (tick >= 1) {
                    tick = 0
                    alphaChannel += step
                    step = if (alphaChannel > defaultAlpha) -10 else if (alphaChannel < 10) 10 else step
                    //Log.trace("alphaChannel = $alphaChannel")
                }
            } else {
                alphaChannel = defaultAlpha
            }
            //rDisableDepth()
            //LibIPNRenderSystem._enableBlend()
            val topLeft = screen.`(containerBounds)`.topLeft
            for ((_, slotTopLeft) in localSlotLocations) {
                val tl = topLeft + slotTopLeft
                rFillRect(context,
                          Rectangle(tl.x,
                                    tl.y,
                                    16,
                                    16),
                          color.alpha(alphaChannel))
            }
            //LibIPNRenderSystem._disableBlend()
            //rEnableDepth()
        } else {
            tick = 0
            alphaChannel = 10
            step = 10
        }
    }

    fun onTickInGame() {
        if (Features.HIGHLIGHT_FOUSED_ITEMS.booleanValue) {
            val screen = Vanilla.screen() as? AbstractContainerScreen<*> ?: return
            screen.`(focusedSlot)`?.let { slot ->
                if (toHighlight != slot.`(itemStack)`.itemType) {
                    ticksSinceLastFocusChange--
                    if (ticksSinceLastFocusChange < 0) {
                        toHighlight = slot.`(itemStack)`.itemType.copy(ignoreDurability = true)
                        ticksSinceLastFocusChange = ModSettings.HIGHLIGHT_FOCUSED_WAIT_TICKS.integerValue
                    }
                } else {
                    ticksSinceLastFocusChange = ModSettings.HIGHLIGHT_FOCUSED_WAIT_TICKS.integerValue
                }
                return
            }
            toHighlight = ItemType.EMPTY
        }
    }
}
