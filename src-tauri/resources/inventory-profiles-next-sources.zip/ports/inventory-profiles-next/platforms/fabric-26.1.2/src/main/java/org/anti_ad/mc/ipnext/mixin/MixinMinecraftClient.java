/*
 * Inventory Profiles Next
 *
 *   Copyright (c) 2019-2020 jsnimda <7615255+jsnimda@users.noreply.github.com>
 *   Copyright (c) 2021-2022 Plamen K. Kosseff <p.kosseff@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package org.anti_ad.mc.ipnext.mixin;

/*
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
*/


import com.mojang.blaze3d.platform.Window;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Options;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.Minecraft;
import net.minecraft.world.inventory.InventoryMenu;
import org.anti_ad.mc.ipnext.config.LockedSlotsSettings;
import org.anti_ad.mc.ipnext.event.ClientEventHandler;
import org.anti_ad.mc.ipnext.event.LockSlotsHandler;
import org.anti_ad.mc.ipnext.event.LockedSlotKeeper;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MixinMinecraftClient
 */
@Mixin(Minecraft.class)
public abstract class MixinMinecraftClient {

    @Shadow
    public LocalPlayer player;

    @Shadow @Final public Options options;

    @Shadow public abstract boolean isPaused();

    @Shadow @Final private Window window;

    @Shadow @Nullable public Screen screen;

    @Inject(at = @At("HEAD"), method = "tick()V")
    public void tick(CallbackInfo info) {
        ClientEventHandler.INSTANCE.onTickPre();
    }

    @Inject(at = @At("RETURN"), method = "tick()V")
    public void tick2(CallbackInfo info) {
        ClientEventHandler.INSTANCE.onTick();
    }

    @Inject(at = @At("RETURN"), method = "setLevel")
    public void joinWorld(ClientLevel level, CallbackInfo ci) {
        if (Minecraft.getInstance().getCurrentServer() != null) {
            ClientEventHandler.INSTANCE.onJoinWorld();
        }
    }

    @Inject(at = @At("HEAD"),
            method = "handleKeybinds()V")
    public void handleInputEventsPre(CallbackInfo info) {
        int selectedSlot = this.player.getInventory().getSelectedSlot() + 36;
        if(LockedSlotsSettings.INSTANCE.getLOCKED_SLOTS_DISABLE_THROW_FOR_NON_STACKABLE().getValue()
           && InventoryMenu.isHotbarSlot(selectedSlot)
           && (options.keyDrop.isDown() || options.keyDrop.consumeClick())) {

            if (!LockSlotsHandler.INSTANCE.isHotbarQMoveActionAllowed(selectedSlot, true)) {
                IMixinKeyBinding drop = (IMixinKeyBinding) options.keyDrop;
                drop.setPressed(false);
                drop.setTimesPressed(0);
            }
        }

        if(LockedSlotsSettings.INSTANCE.getLOCKED_SLOTS_EMPTY_HOTBAR_AS_SEMI_LOCKED().getValue()) {
            KeyMapping keySwapHands = options.keySwapOffhand;
            IMixinKeyBinding keySwapHandsAccessor = (IMixinKeyBinding) keySwapHands;

            if (this.screen == null
                    && InventoryMenu.isHotbarSlot(this.player.getInventory().getSelectedSlot())
                    && keySwapHandsAccessor.getTimesPressed() > 0) {

                LockedSlotKeeper.INSTANCE.setPickingItem(true);
                LockedSlotKeeper.INSTANCE.ignoreSelectedHotbarSlotForHandSwap();
                LockedSlotKeeper.INSTANCE.setPickingItem(false);
            }
        }
    }

    @Inject(at = @At("TAIL"),
            method = "handleKeybinds()V")
    public void handleInputEventsPost(CallbackInfo info) {

    }

    @Inject(at = @At("HEAD"), method = "pickBlockOrEntity()V")
    private void doItemPickPre(CallbackInfo ci) {
        LockedSlotKeeper.INSTANCE.setPickingItem(true);
    }

    @Inject(at = @At("TAIL"), method = "pickBlockOrEntity()V")
    private void doItemPickPost(CallbackInfo ci) {
        LockedSlotKeeper.INSTANCE.setPickingItem(false);
    }

}
