/*
 * Inventory Profiles Next
 *
 *   Copyright (c) 2019-2020 jsnimda <7615255+jsnimda@users.noreply.github.com>
 *   Copyright (c) 2021-2022 Plamen K. Kosseff <p.kosseff@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package org.anti_ad.mc.ipnext.ingame

import net.minecraft.client.gui.screens.Screen
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen
import net.minecraft.world.entity.player.Inventory
import net.minecraft.world.inventory.Slot
import org.anti_ad.mc.common.vanilla.Vanilla

// ============
// vanillamapping code depends on mappings
// ============

private inline val vPlayerSlots
    get() = Vanilla.playerContainer().`(slots)`

fun vPlayerSlotOf(slot: Slot,
                  screen: Screen?): Slot { // creative slot to survival slot
    if (screen !is CreativeModeInventoryScreen) return slot
    val inventory = slot.`(inventoryOrNull)` ?: return slot
    if (inventory !is Inventory) return slot
    val id = slot.`(id)`
    val invSlot = slot.`(invSlot)`
    return when {
        invSlot in 0 .. 8 && id == 45 + invSlot -> vPlayerSlots[36 + invSlot] // hotbar in other tab
        invSlot in 0 .. 45 && id == 0           -> vPlayerSlots[invSlot] // slot in backpack tab
        else                                    -> slot
    }
}

