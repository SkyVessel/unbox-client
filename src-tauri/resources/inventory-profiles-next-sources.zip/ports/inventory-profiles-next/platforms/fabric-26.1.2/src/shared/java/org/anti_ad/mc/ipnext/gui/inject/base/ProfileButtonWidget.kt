/*
 * Inventory Profiles Next
 *
 *   Copyright (c) 2019-2020 jsnimda <7615255+jsnimda@users.noreply.github.com>
 *   Copyright (c) 2021-2022 Plamen K. Kosseff <p.kosseff@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package org.anti_ad.mc.ipnext.gui.inject.base

import org.anti_ad.mc.common.gui.NativeInputContextBase
import org.anti_ad.mc.ipnext.config.Features
import org.anti_ad.mc.ipnext.config.GuiSettings

open class ProfileButtonWidget: SortButtonWidget {

    override var visible: Boolean
        get() = Features.ENABLE_PROFILES.booleanValue && super.visible
        set(value) {
            super.visible = value
        }

    constructor(clickEvent: (Int) -> Unit): super(clickEvent)
    constructor(clickEvent: () -> Unit) : super(clickEvent)
    constructor() : super()

    override fun mouseClicked(context: NativeInputContextBase<*>,
                              x: Int,
                              y: Int,
                              button: Int): Boolean {
        return super.mouseClicked(context, x, y, button) && visible
    }
}
