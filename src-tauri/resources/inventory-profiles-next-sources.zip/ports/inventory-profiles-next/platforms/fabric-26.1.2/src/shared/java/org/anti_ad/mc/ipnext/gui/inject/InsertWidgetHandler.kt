/*
 * Inventory Profiles Next
 *
 *   Copyright (c) 2019-2020 jsnimda <7615255+jsnimda@users.noreply.github.com>
 *   Copyright (c) 2021-2022 Plamen K. Kosseff <p.kosseff@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package org.anti_ad.mc.ipnext.gui.inject

import net.minecraft.client.gui.screens.Screen

import org.anti_ad.mc.common.ScreenEventListener
import org.anti_ad.mc.common.gui.NativeInputContextBase
import org.anti_ad.mc.common.gui.widgets.Widget
import org.anti_ad.mc.common.input.GlobalScreenEventListener
import org.anti_ad.mc.common.math2d.Size
import org.anti_ad.mc.common.vanilla.Vanilla

object InsertWidgetHandler : ScreenEventListener {
    var currentWidgets: MutableList<Widget> = mutableListOf()
    var currentScreen: Screen? = null

    private val initSync = Any()


    fun insertWidget(widgets: List<Widget>?) {
        synchronized(initSync) {
            currentWidgets.clear()
            currentScreen = null
            if (widgets != null) {
                currentScreen = Vanilla.screen()
                currentWidgets.addAll(widgets)
            }
        }
    }
    /*
    fun insertWidget(widget: Widget) {
        currentWidget = widget
        currentScreen = Vanilla.screen()
    }
*/


    override fun resize(//minecraftClient: Any,
                        width: Int,
                        height: Int) {
        if (checkIfValidScreen()) {
            currentWidgets.forEach {
                it.size = Size(width, height)
            }
        }
    }

    override fun mouseClicked(context: NativeInputContextBase<*>,
                              x: Double,
                              y: Double,
                              button: Int): Boolean {
        var r = false
        if (checkIfValidScreen()) {
            currentWidgets.filter { it.visible }.forEach {
                r = r || it.mouseClicked(context, x.toInt(), y.toInt(), button)
            }
        }
        return r
    }

    override fun mouseRelease(context: NativeInputContextBase<*>,
                              x: Double,
                              y: Double,
                              button: Int): Boolean {

        var r = false
        if (checkIfValidScreen()) {
            currentWidgets.filter { it.visible }.forEach {
                r = r || it.mouseReleased(context, x.toInt(), y.toInt(), button)
            }
        }
        return r
    }

    override fun keyPressed(context: NativeInputContextBase<*>,
                            keyCode: Int,
                            scanCode: Int,
                            modifiers: Int): Boolean {
        var r = false
        if (checkIfValidScreen()) {
            currentWidgets.filter { it.visible }.forEach {
                r = r || it.keyPressed(context, keyCode, scanCode, modifiers)
            }
        }
        return r
    }

    override fun keyReleased(context: NativeInputContextBase<*>,
                             keyCode: Int,
                             scanCode: Int,
                             modifiers: Int): Boolean {
        var r = false
        if (checkIfValidScreen()) {
            currentWidgets.filter { it.visible }.forEach {
                r = r || it.keyReleased(context, keyCode, scanCode, modifiers)
            }
        }
        return r
    }

    override fun mouseDragged(context: NativeInputContextBase<*>,
                              x: Double,
                              y: Double,
                              button: Int,
                              dx: Double,
                              dy: Double): Boolean {
        var r = false
        if (checkIfValidScreen()) {
            currentWidgets.filter { it.visible }.forEach {
                r = r || it.mouseDragged(context, x, y, button, dx, dy)
            }
        }
        return r
    }

    override fun mouseScrolled(context: NativeInputContextBase<*>,x: Double,
                               y: Double,
                               horizontal: Double,
                               vertical: Double): Boolean {
        var r = false
        if (checkIfValidScreen()) {
            currentWidgets.filter { it.visible }.forEach {
                r = r || it.mouseScrolled(context, x.toInt(), y.toInt(), horizontal, vertical)
            }
        }
        return r
    }

    override fun charTyped(context: NativeInputContextBase<*>,charIn: Char,
                           modifiers: Int): Boolean {
        var r = false
        if (checkIfValidScreen()) {
            currentWidgets.filter { it.visible }.forEach {
                r = r || it.charTyped(context, charIn, modifiers)
            }
        }
        return r
    }

    fun preScreenRender() {
        synchronized(initSync) {
            if (Vanilla.screen() == null) {
                currentWidgets.clear()
                currentScreen = null
            }
            if (currentScreen != null && Vanilla.screen() != currentScreen) {
                currentWidgets.clear()
                currentScreen = null
            }
        }
    }

    // implement events

    fun onClientInit() {
        GlobalScreenEventListener.registerPre(this)

        // fixme cannot register post, as container screen mouse clicked always return true
    }

    private fun checkIfValidScreen(): Boolean {
        synchronized(initSync) {
            if (Vanilla.screen() == null) {
                currentWidgets.clear()
                currentScreen = null
                return false
            } else {
                return true
            }
        }
    }
}
