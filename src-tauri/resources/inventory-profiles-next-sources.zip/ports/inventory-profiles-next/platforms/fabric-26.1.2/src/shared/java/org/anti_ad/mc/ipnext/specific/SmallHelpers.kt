/*
 * Inventory Profiles Next
 *
 *   Copyright (c) 2019-2020 jsnimda <7615255+jsnimda@users.noreply.github.com>
 *   Copyright (c) 2021-2022 Plamen K. Kosseff <p.kosseff@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

@file:Suppress("NOTHING_TO_INLINE")

package org.anti_ad.mc.ipnext.specific

import net.minecraft.SharedConstants

import org.anti_ad.mc.common.gui.NativeContext
import org.anti_ad.mc.common.vanilla.Vanilla.mc
import org.anti_ad.mc.ipnext.IPNInfoManager

inline fun serverIdentifier(perServer: Boolean): String = when {
    !perServer -> {
        ""
    }
    mc().isLocalServer                  -> { //isSingleplayer
        (mc().singleplayerServer?.worldData?.levelName ?: "") //serverConfiguration?.worldName ?: "" // integratedServer
    }
    mc().currentServer?.isRealm == true -> {
        "@realms"
        //(mc().connection?.connection?.remoteAddress?.toString()?.replace("/","")?.replace(":","&") ?: "").sanitized()
    }
    mc().currentServer != null          -> {
        (mc().currentServer?.ip?.replace("/","")?.replace(":","&") ?: "")
    }
    else -> {
        ""
    }
}

inline fun initInfoManager() {
    IPNInfoManager.loader = "neoforge"
    IPNInfoManager.mcVersion = SharedConstants.getCurrentVersion().id()
}

val NativeContext.asOverlayContext: NativeContext
    get() {
        return NativeContext(this.native).apply {
            isOverlay = true
        }
    }
