/*
 * Inventory Profiles Next
 *
 *   Copyright (c) 2022 Plamen K. Kosseff <p.kosseff@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package org.anti_ad.mc.ipnext.gui.inject.base

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen

import org.anti_ad.mc.common.extensions.tryCatch
import org.anti_ad.mc.common.gui.NativeContext
import org.anti_ad.mc.common.gui.layout.fillParent
import org.anti_ad.mc.common.gui.layout.setTopLeft
import org.anti_ad.mc.common.gui.screen.ConfigScreenBase
import org.anti_ad.mc.ipnext.gui.widgets.Hintable
import org.anti_ad.mc.ipnext.integration.ButtonPositionHint
import org.anti_ad.mc.ipnext.integration.HintClassData
import org.anti_ad.mc.ipnext.integration.HintsManagerNG
import org.anti_ad.mc.common.math2d.Rectangle
import org.anti_ad.mc.common.vanilla.Vanilla
import org.anti_ad.mc.common.vanilla.alias.glue.I18n
import org.anti_ad.mc.common.vanilla.VanillaScreenUtil
import org.anti_ad.mc.common.vanilla.render.glue.rDrawOutline
import org.anti_ad.mc.common.vanilla.render.opaque
import org.anti_ad.mc.ipn.api.IPNButton
import org.anti_ad.mc.ipnext.config.ConfigScreenSettings
import org.anti_ad.mc.ipnext.config.Debugs
import org.anti_ad.mc.ipnext.config.GuiSettings

class SettingsWidget(override val screen: AbstractContainerScreen<*>,
                     hintsData: HintClassData = HintsManagerNG.getHints(screen.javaClass)): InsertableWidget(), Hintable {

    override var hints: ButtonPositionHint = hintsData.hintFor(IPNButton.SETTINGS)

    override var underManagement: Boolean = false

    override var hintManagementRenderer = Hintable.HintManagementRenderer(this)

    override val container = Vanilla.container()

    override fun postBackgroundRender(context: NativeContext,
                                      mouseX: Int,
                                      mouseY: Int,
                                      partialTicks: Float) {
    }

    override fun postForegroundRender(context: NativeContext,
                                      mouseX: Int,
                                      mouseY: Int,
                                      partialTicks: Float) {
        fillParent()

        //overflow = Overflow.VISIBLE
        absoluteBounds = Rectangle(0,
                                   0,
                                   containerWidth,
                                   containerHeight)
        init()
        rehint()
        visible = GuiSettings.ENABLE_INVENTORY_SETTINGS_BUTTON.booleanValue
        super.render(context,
                     mouseX,
                     mouseY,
                     partialTicks)

        hintManagementRenderer.renderUnderManagement(context)

        if (Debugs.DEBUG_RENDER.booleanValue) {
            rDrawOutline(context,
                         absoluteBounds,
                         0xffff00.opaque)
        }

    }

    var rehint = {}

    private var initialized = false

    fun init() {
        if (initialized) return
        initialized = true
        InitWidgets().also { rehint = it::reHint }
        fillParent()

        //overflow = Overflow.VISIBLE
        absoluteBounds = Rectangle( 0,
                                    0,
                                    containerWidth,
                                    containerHeight)

    }

    inner class InitWidgets { // todo cleanup code


        private val showHideButton = SortButtonWidget{ -> onClick() }.apply {
            tx = 140
            ty = 0
            hints = this@SettingsWidget.hints
            this@SettingsWidget.snapableList.add(this)
            this@SettingsWidget.addChild(this)
            visible = GuiSettings.ENABLE_INVENTORY_SETTINGS_BUTTON.value
            tooltipText = I18n.translate("inventoryprofiles.tooltip.settings_open")
            zIndex = 0
            hintableList.add(this)
        }

        fun reHint() {
            val settingsTop = GuiSettings.SETTINGS_TOP.integerValue
            val settingsLeft = GuiSettings.SETTINGS_LEFT.integerValue

            if (hints.top < -settingsTop) hints.top = -settingsTop
            if (hints.top > containerHeight - 20) hints.top = containerHeight - 20

            if (hints.horizontalOffset < -settingsLeft) hints.horizontalOffset = -settingsLeft
            if (hints.horizontalOffset > containerWidth - 25) hints.horizontalOffset = containerWidth - 25

            showHideButton.setTopLeft(settingsTop + hints.top,
                                      settingsLeft + hints.horizontalOffset)
        }

        init {
            reHint()
        }

    }

    fun onClick() {
        Vanilla.queueForMainThread {
            tryCatch {
                VanillaScreenUtil.closeScreenGracefully()
            }
            ConfigScreenBase(ConfigScreenSettings).let {
                VanillaScreenUtil.openDistinctScreen(it)
            }
        }
    }
}
